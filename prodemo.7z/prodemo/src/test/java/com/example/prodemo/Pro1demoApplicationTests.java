package com.example.prodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pro1demoApplicationTests {

	@Test
	void contextLoads() {
	}

}
