package com.example.prodemo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "products")
public class Product {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
   	private String ProductName;
   	private String ProductType;
   	private String ProductCategory;
   	private String ProductPrize;
   	private String ProductCode;

	public String getProductCode() {
		return ProductCode;
	}
	public void setProductCode(String productCode) {
		ProductCode = productCode;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public String getProductType() {
		return ProductType;
	}
	public void setProductType(String productType) {
		ProductType = productType;
	}
	public String getProductCategory() {
		return ProductCategory;
	}
	public void setProductCategory(String productCategory) {
		ProductCategory = productCategory;
	}
	public String getProductPrize() {
		return ProductPrize;
	}
	public void setProductPrize(String productPrize) {
		ProductPrize = productPrize;
	}
	
	
	
	
	
	public Product(Long id, String productName, String productType, String productCategory, String productPrize,
			String productCode) {
		super();
		this.id = id;
		ProductName = productName;
		ProductType = productType;
		ProductCategory = productCategory;
		ProductPrize = productPrize;
		ProductCode = productCode;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", ProductName=" + ProductName + ", ProductType=" + ProductType
				+ ", ProductCategory=" + ProductCategory + ", ProductPrize=" + ProductPrize + ", ProductCode="
				+ ProductCode + "]";
	}
	
	
	
	



}
