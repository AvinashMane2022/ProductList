package com.example.prodemo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.prodemo.entity.Product;
import com.example.prodemo.repository.ProductRepository;


@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
    private ProductRepository productRepository;
	
	@Override
	public List<Product> getAllProduct() {
		return productRepository.findAll();
	}

	@Override
	public Optional<Product> getProductId(Long productId) {
		return productRepository.findById(productId);
	}
	

	@Override
	public Product createProduct(Product product) {
//		Product Product1= productRepository.findByProductCode(product.getProductCode());
//		if(Product1 != null) {
//			return ("Product Already Present With This Id : " + Product1.getProductCode());
//			
//		}else
//		{
//			Product pro1 = productRepository.save(product);
//			return ("product Add Successfully : " + pro1.getId());
//		}	
		return productRepository.save(product);
		}

	@Override
	public Product updateProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public void deleteProduct(Product product) {
		productRepository.delete(product);		
	}


	@Override
	public Product getProductByProductCode(Product productCode) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public Product getProductById(String Id) {
//		// TODO Auto-generated method stub
//		return productRepository.findById(Id) ;
//	}


}
