package com.example.prodemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.prodemo.entity.Product;

import io.swagger.v3.oas.annotations.servers.Server;

@Service

public interface ProductService {

	public List<Product> getAllProduct();
	public Optional<Product> getProductId(Long productId);
	public Product getProductByProductCode(Product productCode);
	public Product createProduct(Product product);
	public Product updateProduct(Product product);
	public void deleteProduct(Product product);

}
